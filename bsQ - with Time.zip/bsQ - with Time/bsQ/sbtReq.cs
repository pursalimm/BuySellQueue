﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using gma.System.Windows;

namespace bsQ
{
    public partial class sbtReq : Form
    {
        bool flag = false;
        Point pt = new Point();
        Random rnd = new Random();
        UserActivityHook actHook;
        TimeSpan curTime, startTime, endTime;
        public sbtReq()
        {
            InitializeComponent();
            this.Location = new Point((Screen.PrimaryScreen.Bounds.Width / 2) - (this.Width / 2), 0);
        }

        // Mouse event flags.
        [Flags]
        public enum MouseEventFlags : uint
        {
            LEFTDOWN = 0x00000002,
            LEFTUP = 0x00000004,
            MIDDLEDOWN = 0x00000020,
            MIDDLEUP = 0x00000040,
            MOVE = 0x00000001,
            ABSOLUTE = 0x00008000,
            RIGHTDOWN = 0x00000008,
            RIGHTUP = 0x00000010,
            WHEEL = 0x00000800,
            XDOWN = 0x00000080,
            XUP = 0x00000100
        }

        [DllImport("user32.dll")]
        static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, int dwExtraInfo);
        private void timeR_Tick(object sender, EventArgs e)
        {
            nowTime.Text = DateTime.Now.ToString("HH:mm:ss.fff");
            curTime = TimeSpan.Parse(nowTime.Text);
            startTime = TimeSpan.Parse(stTime.Text);
            endTime = startTime.Add(TimeSpan.FromSeconds((double)udDuration.Value));
            remainTime.Text = ((TimeSpan)(startTime - curTime)).TotalSeconds.ToString();

            txtPos.Text = Cursor.Position.X.ToString() + ", " + Cursor.Position.Y.ToString();

            if (curTime.Hours == startTime.Hours && curTime.Minutes == startTime.Minutes && curTime.Seconds == startTime.Seconds)
                flag = true;
            if (curTime.Hours >= endTime.Hours && curTime.Minutes >= endTime.Minutes && curTime.Seconds >= endTime.Seconds)
                flag = false;
            
            if (flag)
            {
                pt = bsQ.Properties.Settings.Default.point;
                Rectangle screen_bounds = Screen.GetBounds(pt);
                uint x = (uint)(pt.X * 65535 / screen_bounds.Width);
                uint y = (uint)(pt.Y * 65535 / screen_bounds.Height);

                string[] strGap = gapBreak.Text.Split(':');
                if (int.Parse(strGap[0]) > int.Parse(strGap[1]))
                {
                    gapBreak.Text = strGap[1] + ":" + strGap[0];
                    strGap = gapBreak.Text.Split(':');
                }

                if (chkMove.Checked == true)
                {   // Move the mouse.
                    mouse_event((uint)(MouseEventFlags.ABSOLUTE | MouseEventFlags.MOVE), x, y, 0, 0);
                    if (chkClick.Checked == true)
                    {   // Click there.
                        mouse_event((uint)(MouseEventFlags.ABSOLUTE | MouseEventFlags.MOVE | MouseEventFlags.LEFTDOWN | MouseEventFlags.LEFTUP), x, y, 0, 0);
                        System.Threading.Thread.Sleep(rnd.Next(int.Parse(strGap[0]), int.Parse(strGap[1])));
                    }
                }
            }
        }
        private void sbtReq_Load(object sender, EventArgs e)
        {
            actHook = new UserActivityHook(); // crate an instance with global hooks
            actHook.KeyDown += new KeyEventHandler(MyKeyDown);

            pt = bsQ.Properties.Settings.Default.point;
            txtLoc.Text= pt.ToString();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void MyKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9)
            {
                pt.X = Cursor.Position.X;
                pt.Y = Cursor.Position.Y;
                bsQ.Properties.Settings.Default.point = pt;
                bsQ.Properties.Settings.Default.Save();
                txtLoc.Text = pt.ToString();
            }
            else if (e.KeyData == Keys.F10)
            {
                pt = bsQ.Properties.Settings.Default.point;
                Rectangle screen_bounds = Screen.GetBounds(pt);
                uint x = (uint)(pt.X * 65535 / screen_bounds.Width);
                uint y = (uint)(pt.Y * 65535 / screen_bounds.Height);

                // Move the mouse.
                mouse_event((uint)(MouseEventFlags.ABSOLUTE | MouseEventFlags.MOVE), x, y, 0, 0);
                // Click there.
                mouse_event((uint)(MouseEventFlags.ABSOLUTE | MouseEventFlags.MOVE | MouseEventFlags.LEFTDOWN | MouseEventFlags.LEFTUP), x, y, 0, 0);
            }
        }

        private void udInterval_ValueChanged(object sender, EventArgs e)
        {
            timeR.Interval = (int)udDuration.Value;
        }
    }
}
