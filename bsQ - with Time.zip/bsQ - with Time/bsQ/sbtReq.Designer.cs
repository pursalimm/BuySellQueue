﻿namespace bsQ
{
    partial class sbtReq
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sbtReq));
            this.timeR = new System.Windows.Forms.Timer(this.components);
            this.chkMove = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chkClick = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.remainTime = new System.Windows.Forms.TextBox();
            this.txtLoc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.udDuration = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtPos = new System.Windows.Forms.TextBox();
            this.stTime = new System.Windows.Forms.DateTimePicker();
            this.gapBreak = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.PictureBox();
            this.nowTime = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.udDuration)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).BeginInit();
            this.SuspendLayout();
            // 
            // timeR
            // 
            this.timeR.Enabled = true;
            this.timeR.Interval = 1;
            this.timeR.Tick += new System.EventHandler(this.timeR_Tick);
            // 
            // chkMove
            // 
            this.chkMove.AutoSize = true;
            this.chkMove.Checked = true;
            this.chkMove.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMove.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMove.Location = new System.Drawing.Point(485, 3);
            this.chkMove.Name = "chkMove";
            this.chkMove.Size = new System.Drawing.Size(53, 17);
            this.chkMove.TabIndex = 3;
            this.chkMove.Text = "Move";
            this.chkMove.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(109, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Start time";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkClick
            // 
            this.chkClick.AutoSize = true;
            this.chkClick.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkClick.Location = new System.Drawing.Point(485, 23);
            this.chkClick.Name = "chkClick";
            this.chkClick.Size = new System.Drawing.Size(112, 17);
            this.chkClick.TabIndex = 4;
            this.chkClick.Text = "Click (                  )";
            this.chkClick.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(109, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Position (      )";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // remainTime
            // 
            this.remainTime.BackColor = System.Drawing.Color.White;
            this.remainTime.Enabled = false;
            this.remainTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remainTime.ForeColor = System.Drawing.Color.Black;
            this.remainTime.Location = new System.Drawing.Point(266, 0);
            this.remainTime.Name = "remainTime";
            this.remainTime.Size = new System.Drawing.Size(60, 20);
            this.remainTime.TabIndex = 0;
            this.remainTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLoc
            // 
            this.txtLoc.BackColor = System.Drawing.Color.White;
            this.txtLoc.Enabled = false;
            this.txtLoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoc.Location = new System.Drawing.Point(180, 21);
            this.txtLoc.Name = "txtLoc";
            this.txtLoc.Size = new System.Drawing.Size(85, 20);
            this.txtLoc.TabIndex = 3;
            this.txtLoc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(337, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 27;
            this.label1.Text = "Duration (s)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // udDuration
            // 
            this.udDuration.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.udDuration.Location = new System.Drawing.Point(419, 0);
            this.udDuration.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.udDuration.Name = "udDuration";
            this.udDuration.Size = new System.Drawing.Size(49, 20);
            this.udDuration.TabIndex = 1;
            this.udDuration.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.udDuration.ValueChanged += new System.EventHandler(this.udInterval_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(337, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 13);
            this.label7.TabIndex = 32;
            this.label7.Text = "Gap breaks (ms)";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.Window;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(155, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 12);
            this.label13.TabIndex = 40;
            this.label13.Text = "F9";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtPos
            // 
            this.txtPos.BackColor = System.Drawing.Color.White;
            this.txtPos.Enabled = false;
            this.txtPos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPos.Location = new System.Drawing.Point(266, 21);
            this.txtPos.Name = "txtPos";
            this.txtPos.Size = new System.Drawing.Size(60, 20);
            this.txtPos.TabIndex = 47;
            this.txtPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // stTime
            // 
            this.stTime.CustomFormat = "HH:mm:ss";
            this.stTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.stTime.Location = new System.Drawing.Point(180, 0);
            this.stTime.Name = "stTime";
            this.stTime.ShowUpDown = true;
            this.stTime.Size = new System.Drawing.Size(85, 20);
            this.stTime.TabIndex = 0;
            // 
            // gapBreak
            // 
            this.gapBreak.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gapBreak.Location = new System.Drawing.Point(419, 21);
            this.gapBreak.Mask = "000:000";
            this.gapBreak.Name = "gapBreak";
            this.gapBreak.Size = new System.Drawing.Size(49, 20);
            this.gapBreak.TabIndex = 2;
            this.gapBreak.Text = "100300";
            this.gapBreak.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Window;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(533, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 56;
            this.label4.Text = "Test: F10";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnExit
            // 
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.Location = new System.Drawing.Point(612, 6);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(30, 30);
            this.btnExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnExit.TabIndex = 57;
            this.btnExit.TabStop = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // nowTime
            // 
            this.nowTime.AutoSize = true;
            this.nowTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nowTime.Location = new System.Drawing.Point(14, 15);
            this.nowTime.Name = "nowTime";
            this.nowTime.Size = new System.Drawing.Size(57, 13);
            this.nowTime.TabIndex = 59;
            this.nowTime.Text = "nowTime";
            this.nowTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sbtReq
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(649, 41);
            this.ControlBox = false;
            this.Controls.Add(this.nowTime);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.gapBreak);
            this.Controls.Add(this.stTime);
            this.Controls.Add(this.txtLoc);
            this.Controls.Add(this.txtPos);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.udDuration);
            this.Controls.Add(this.chkMove);
            this.Controls.Add(this.remainTime);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.chkClick);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "sbtReq";
            this.Opacity = 0.95D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Buy & Sell Queue (Pursalimm@gmail.com)";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.sbtReq_Load);
            ((System.ComponentModel.ISupportInitialize)(this.udDuration)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timeR;
        private System.Windows.Forms.CheckBox chkMove;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkClick;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox remainTime;
        private System.Windows.Forms.TextBox txtLoc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown udDuration;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtPos;
        private System.Windows.Forms.DateTimePicker stTime;
        private System.Windows.Forms.MaskedTextBox gapBreak;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox btnExit;
        private System.Windows.Forms.Label nowTime;
    }
}